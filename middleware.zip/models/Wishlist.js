


import mongoose from 'mongoose';

const WishlistSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  productId: { type: String, required: true },
  productTitle: { type: String },
  productPrice: { type: Number },
  productImg: { type: String },
  productData: { type: Object },
  user: {
    name: { type: String },
    email: { type: String },
    phone: { type: String },
  },
  like: { type: Number, default: 1 },
  addedAt: { type: Date, default: Date.now },
});

export default mongoose.model("Wishlist", WishlistSchema);